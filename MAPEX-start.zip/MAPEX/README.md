# MAPEX – Android

Pierwszy fundament aplikacji MAPEX: natywna aplikacja Android w Kotlinie z MapLibre.

## Budowanie APK bez komputera
1. Utwórz nowe publiczne lub prywatne repozytorium GitHub o nazwie `MAPEX`.
2. Wgraj wszystkie pliki z tego archiwum, zachowując strukturę katalogów.
3. Otwórz zakładkę **Actions** i wybierz **Build MAPEX APK**.
4. Kliknij **Run workflow** (albo poczekaj na automatyczny build po pushu).
5. Po zakończeniu otwórz uruchomiony workflow i pobierz artefakt `MAPEX-debug-APK`.
6. Rozpakuj ZIP z artefaktem i zainstaluj `app-debug.apk` na Androidzie.

## Stan wersji 0.1.0
- Interaktywna mapa MapLibre (internet jest wymagany).
- Start kamery w okolicy Ostrowa Wielkopolskiego.
- Przycisk centrowania na ostatniej znanej lokalizacji GPS (po przyznaniu uprawnienia).
- Przyciski ZGŁOŚ i TRASA są na razie informacyjne – moduły będą dodawane etapami.

## Ważne
To jest działający fundament, a nie jeszcze pełny zamiennik Google Maps/Yanosika. Do uruchomienia produkcyjnego potrzebne będą stabilne źródła kafelków, geokodowania i routingu oraz własny backend zgłoszeń. Publiczne serwery demonstracyjne nie gwarantują dostępności ani limitów.

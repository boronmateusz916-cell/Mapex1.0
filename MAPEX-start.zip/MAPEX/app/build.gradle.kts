plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pl.mapex.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "pl.mapex.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    implementation("org.maplibre.gl:android-sdk:11.8.0")
}

package pl.mapex.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.MapLibreMap

class MainActivity : Activity() {
    private lateinit var mapView: MapView
    private var map: MapLibreMap? = null
    private lateinit var locationManager: LocationManager
    private val requestLocation = 4101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.rgb(12, 18, 28))
        mapView = MapView(this)
        root.addView(mapView, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            setBackgroundColor(Color.rgb(15, 23, 36))
            elevation = dp(8).toFloat()
        }
        val brand = TextView(this).apply {
            text = "MAPEX"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Twoja mapa. Twoja droga."
            textSize = 12f
            setTextColor(Color.rgb(157, 177, 201))
        }
        header.addView(brand)
        header.addView(subtitle)
        val headerParams = FrameLayout.LayoutParams(-1, -2, Gravity.TOP)
        headerParams.setMargins(dp(12), dp(12), dp(12), 0)
        root.addView(header, headerParams)

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            setBackgroundColor(Color.rgb(15, 23, 36))
            elevation = dp(8).toFloat()
        }
        val status = TextView(this).apply {
            text = "Mapa gotowa • Ostrów Wielkopolski"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(9))
        }
        bottom.addView(status)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val locate = makeButton("MOJA POZYCJA")
        val report = makeButton("ZGŁOŚ")
        val route = makeButton("TRASA")
        buttons.addView(locate, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        buttons.addView(report, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        buttons.addView(route, LinearLayout.LayoutParams(0, dp(48), 1f))
        bottom.addView(buttons)
        val bottomParams = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
        bottomParams.setMargins(dp(12), 0, dp(12), dp(12))
        root.addView(bottom, bottomParams)

        locate.setOnClickListener { centerOnMyLocation() }
        report.setOnClickListener {
            Toast.makeText(this, "Moduł zgłoszeń drogowych dodamy w kolejnym etapie.", Toast.LENGTH_LONG).show()
        }
        route.setOnClickListener {
            Toast.makeText(this, "Moduł wyznaczania tras dodamy w kolejnym etapie.", Toast.LENGTH_LONG).show()
        }

        setContentView(root)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { mapbox ->
            map = mapbox
            mapbox.setStyle("https://demotiles.maplibre.org/style.json") {
                mapbox.cameraPosition = CameraPosition.Builder()
                    .target(LatLng(51.646, 17.812))
                    .zoom(12.0)
                    .build()
            }
        }
    }

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        textSize = 10f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(35, 112, 220))
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun centerOnMyLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestLocation)
            return
        }
        try {
            val providers = locationManager.getProviders(true)
            var best: Location? = null
            for (provider in providers) {
                val candidate = locationManager.getLastKnownLocation(provider) ?: continue
                if (best == null || candidate.accuracy < best.accuracy) best = candidate
            }
            if (best != null) {
                map?.animateCamera(
                    org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(
                        LatLng(best.latitude, best.longitude), 16.0
                    )
                )
                Toast.makeText(this, "Pokazuję ostatnią znaną pozycję GPS.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Brak ostatniej pozycji. Włącz GPS i spróbuj ponownie.", Toast.LENGTH_LONG).show()
            }
        } catch (_: SecurityException) {
            Toast.makeText(this, "Brak uprawnień do lokalizacji.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestLocation && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            centerOnMyLocation()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() { mapView.onDestroy(); super.onDestroy() }
    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState) }
}
